/*
 * Init Lab - answers-q5.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _ANSWERS_Q5_H
#define _ANSWERS_Q5_H

// -----------------------------------------------------------------
// Reportez ici les réponses que vous avez trouvées à la question 5.
// -----------------------------------------------------------------

// Report here the answer for question 5. a)
char Q5_ANS_A[] = "/tmp/filewriter_secret_2613ed208ca20efb"; //TODO

// Report here the answer for question 5. b)
char Q5_ANS_B[] = "/tmp/filewriter_secret_child_b90d89c7ada5fe4f"; //TODO

// Report here the answer for question 5. c)
char Q5_ANS_C[] = "1fdda0a15564b77c58246a3dad2d4ae4e3ed827dc7e2a1bcf050ed9dec2c2a99"; //TODO

// Report here the answer for question 5. d)
char Q5_ANS_D[] = "fputs"; //TODO

// Report here the answer for question 5. e)
char Q5_ANS_E[] = "PROCSLEEPTIME"; //TODO

#endif
